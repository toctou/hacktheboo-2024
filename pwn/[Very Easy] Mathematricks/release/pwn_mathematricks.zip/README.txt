1. Connect to the <IP> and <PORT> given and answer the questions to get the flag. ("nc" is recommended). 
   $ nc <IP> <PORT> e.g. nc 127.0.0.1 1337

2. You can modify and use the "solver.py" script to send the payload or simply "nc" and answer the questions.
   $ python3 solver.py

3. "glibc" folder is NOT needed to exploit the challenge, it's just there for the challenge to run.
