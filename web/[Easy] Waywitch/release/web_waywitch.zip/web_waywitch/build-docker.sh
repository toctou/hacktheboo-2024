docker build . -t very-easy-sqli
docker run -it -p 1337:1337 very-easy-sqli
