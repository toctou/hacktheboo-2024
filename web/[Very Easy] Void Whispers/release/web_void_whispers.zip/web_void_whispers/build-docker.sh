docker build . -t web_void_whispers
docker run -it -p 1337:1337 web_void_whispers
